from zypher_trading_bot.main import run
